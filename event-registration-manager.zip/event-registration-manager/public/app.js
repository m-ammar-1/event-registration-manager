const API_URL = "/attendees";

const form = document.getElementById("attendeeForm");
const formError = document.getElementById("formError");
const tableBody = document.getElementById("attendeeBody");
const emptyState = document.getElementById("emptyState");
const totalRevenueEl = document.getElementById("totalRevenue");
const attendeeCountEl = document.getElementById("attendeeCount");

let attendees = [];

// ---------- API calls ----------
async function loadAttendees() {
  try {
    const res = await fetch(API_URL);
    attendees = await res.json();
    render();
  } catch (err) {
    showError("Could not load attendees. Is the server running?");
  }
}

async function addAttendee(data) {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const { error } = await res.json();
    throw new Error(error || "Failed to add attendee");
  }
  return res.json();
}

async function removeAttendee(id) {
  const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete attendee");
}

// ---------- validation ----------
function validate({ name, event, ticketType, ticketPrice }) {
  if (!name.trim() || !event.trim() || !ticketType || ticketPrice === "") {
    return "All fields are required. Please fill in every field.";
  }
  if (Number(ticketPrice) < 0 || Number.isNaN(Number(ticketPrice))) {
    return "Ticket price must be a valid number of 0 or more.";
  }
  return null;
}

function showError(message) {
  formError.textContent = message;
  formError.classList.remove("d-none");
}

function clearError() {
  formError.classList.add("d-none");
  formError.textContent = "";
}

// ---------- revenue (reduce + destructuring) ----------
function calculateRevenue(list) {
  return list.reduce((sum, { ticketPrice }) => sum + Number(ticketPrice), 0);
}

// ---------- rendering (DOM manipulation) ----------
function render() {
  tableBody.innerHTML = "";

  attendees.forEach(({ id, name, event, ticketType, ticketPrice }, index) => {
    const row = document.createElement("tr");

    const cells = [index + 1, name, event].map((value) => {
      const td = document.createElement("td");
      td.textContent = value;
      return td;
    });

    const typeTd = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = `badge ${ticketType === "VIP" ? "text-bg-warning" : "text-bg-secondary"}`;
    badge.textContent = ticketType;
    typeTd.appendChild(badge);

    const priceTd = document.createElement("td");
    priceTd.className = "text-end";
    priceTd.textContent = `PKR ${Number(ticketPrice).toLocaleString()}`;

    const actionTd = document.createElement("td");
    actionTd.className = "text-end";
    const delBtn = document.createElement("button");
    delBtn.className = "btn btn-sm btn-outline-danger";
    delBtn.textContent = "Remove";
    delBtn.addEventListener("click", () => handleDelete(id));
    actionTd.appendChild(delBtn);

    row.append(...cells, typeTd, priceTd, actionTd);
    tableBody.appendChild(row);
  });

  emptyState.classList.toggle("d-none", attendees.length > 0);
  totalRevenueEl.textContent = `PKR ${calculateRevenue(attendees).toLocaleString()}`;
  attendeeCountEl.textContent = attendees.length;
}

// ---------- event handlers ----------
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearError();

  const data = {
    name: document.getElementById("name").value,
    event: document.getElementById("event").value,
    ticketType: document.getElementById("ticketType").value,
    ticketPrice: document.getElementById("ticketPrice").value,
  };

  const problem = validate(data);
  if (problem) {
    showError(problem);
    return;
  }

  try {
    const created = await addAttendee(data);
    attendees = [...attendees, created]; // spread operator
    render();
    form.reset();
  } catch (err) {
    showError(err.message);
  }
});

async function handleDelete(id) {
  try {
    await removeAttendee(id);
    attendees = attendees.filter((a) => a.id !== id);
    render();
  } catch (err) {
    showError(err.message);
  }
}

loadAttendees();
